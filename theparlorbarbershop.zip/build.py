#!/usr/bin/env python3
"""Assembles the static site from shared partials so the header, footer and
head block stay identical across every page. Run: python3 build.py"""

import json, pathlib

ROOT = pathlib.Path(__file__).parent
BASE = "https://theparlorbarbershop.com"

head_common = (ROOT / "_head.part").read_text()
header = (ROOT / "_header.part").read_text()
footer = (ROOT / "_footer.part").read_text()

BIZ = {
    "@type": "BarberShop",
    "@id": BASE + "/#shop",
    "name": "The Parlor Barbershop",
    "url": BASE + "/",
    "telephone": "+1-469-677-0690",
    "priceRange": "$$",
    "image": BASE + "/assets/og-image.svg",
    "address": {
        "@type": "PostalAddress",
        "streetAddress": "1209 Fort Worth Avenue",
        "addressLocality": "Dallas",
        "addressRegion": "TX",
        "postalCode": "75208",
        "addressCountry": "US",
    },
    "areaServed": [
        {"@type": "Place", "name": "Oak Cliff, Dallas"},
        {"@type": "Place", "name": "West Dallas"},
    ],
    "sameAs": ["https://www.instagram.com/theparlor/"],
    "openingHoursSpecification": [
        {"@type": "OpeningHoursSpecification",
         "dayOfWeek": ["Tuesday", "Wednesday", "Thursday", "Friday"],
         "opens": "09:00", "closes": "17:00"},
        {"@type": "OpeningHoursSpecification",
         "dayOfWeek": ["Saturday"], "opens": "09:00", "closes": "15:00"},
    ],
    "makesOffer": [
        {"@type": "Offer", "itemOffered": {"@type": "Service", "name": "Haircut"},
         "price": "40.00", "priceCurrency": "USD"},
        {"@type": "Offer", "itemOffered": {"@type": "Service", "name": "Beard grooming, added to a haircut"},
         "price": "10.00", "priceCurrency": "USD"},
        {"@type": "Offer", "itemOffered": {"@type": "Service", "name": "Hot towel shave"}},
        {"@type": "Offer", "itemOffered": {"@type": "Service", "name": "Children's haircut"}},
    ],
}

FAQ = {
    "@type": "FAQPage",
    "mainEntity": [
        ("Do you take walk-ins?",
         "Booking is the reliable way in. Walk-in availability changes hour to hour depending on "
         "who is in and how the book looks, so ring the shop first."),
        ("Do you cut children's hair?",
         "Yes, and regularly. Parents bring children in alongside their own appointments. If it is "
         "a first haircut, say so when you book so the slot runs a little longer."),
        ("So what is it going to cost me?",
         "A haircut is posted at $40 and a beard added to it at $10, on barber Eddie Sanchez's "
         "rates. Rates can vary between barbers, so ask when you book."),
        ("Are hot towel shaves still on?",
         "Ask for it at the time of booking rather than on arrival. A shave needs the chair held "
         "longer than a cut. Booked ahead, it is a straightforward yes."),
        ("I don't really know what to ask for.",
         "Say that out loud at the start. Tell us how you wore it when you liked it, how much time "
         "you will spend on it in the morning, and how long you want between visits."),
    ],
}


def faq_ld():
    return {
        "@type": "FAQPage",
        "mainEntity": [
            {"@type": "Question", "name": q,
             "acceptedAnswer": {"@type": "Answer", "text": a}}
            for q, a in FAQ["mainEntity"]
        ],
    }


def crumbs(items):
    return {
        "@type": "BreadcrumbList",
        "itemListElement": [
            {"@type": "ListItem", "position": i + 1, "name": n, "item": BASE + u}
            for i, (n, u) in enumerate(items)
        ],
    }


PAGES = [
    {
        "file": "index.html",
        "body": "_body_index.part",
        "slug": "/",
        "title": "The Parlor Barbershop — Haircuts, beards and hot towel shaves in Oak Cliff, Dallas",
        "desc": "A barbershop at 1209 Fort Worth Avenue, Dallas. Haircuts from $40, beard work, "
                "hot towel shaves. Open Tuesday to Saturday. Book a chair or call (469) 677-0690.",
        "og_title": "The Parlor Barbershop — Oak Cliff, Dallas",
        "nav": "home",
        "ld": [BIZ, faq_ld(), {"@type": "WebSite", "name": "The Parlor Barbershop", "url": BASE + "/"}],
    },
    {
        "file": "services.html",
        "body": "_body_services.part",
        "slug": "/services.html",
        "title": "Services and prices — The Parlor Barbershop, Dallas",
        "desc": "Haircut $40, beard added to a cut $10, hot towel shaves and children's haircuts. "
                "What is included, what we don't do, and how to book each one.",
        "og_title": "Services and prices — The Parlor Barbershop",
        "nav": "services",
        "ld": [BIZ, crumbs([("Home", "/"), ("Services", "/services.html")])],
    },
    {
        "file": "shop.html",
        "body": "_body_shop.part",
        "slug": "/shop.html",
        "title": "The Shop — The Parlor Barbershop on Fort Worth Avenue",
        "desc": "A barbershop on Fort Worth Avenue cutting for Oak Cliff and West Dallas. How we "
                "work, whose hands you are in, and the Saturday in 2018 we cut for Vogel Alcove.",
        "og_title": "The Shop — The Parlor Barbershop",
        "nav": "shop",
        "ld": [BIZ, crumbs([("Home", "/"), ("The Shop", "/shop.html")])],
    },
    {
        "file": "visit.html",
        "body": "_body_visit.part",
        "slug": "/visit.html",
        "title": "Visit and hours — The Parlor Barbershop, 1209 Fort Worth Avenue",
        "desc": "Open Tuesday to Friday 9–5 and Saturday 9–3 at 1209 Fort Worth Avenue, Dallas "
                "75208. Call (469) 677-0690, book on Booksy, or send a request.",
        "og_title": "Visit The Parlor — 1209 Fort Worth Avenue, Dallas",
        "nav": "visit",
        "ld": [BIZ, crumbs([("Home", "/"), ("Visit", "/visit.html")])],
    },
    {
        "file": "404.html",
        "body": "_body_404.part",
        "slug": "/404.html",
        "title": "Page not found — The Parlor Barbershop",
        "desc": "That page is not on this site. Booking, services, hours and directions for The "
                "Parlor Barbershop, 1209 Fort Worth Avenue, Dallas.",
        "og_title": "Page not found — The Parlor Barbershop",
        "nav": None,
        "noindex": True,
        "ld": [BIZ],
    },
]

TEMPLATE = """<!doctype html>
<html lang="en-US" class="no-js">
<head>
{head}
<title>{title}</title>
<meta name="description" content="{desc}">
<link rel="canonical" href="{canonical}">
{robots}<meta property="og:type" content="website">
<meta property="og:site_name" content="The Parlor Barbershop">
<meta property="og:locale" content="en_US">
<meta property="og:title" content="{og_title}">
<meta property="og:description" content="{desc}">
<meta property="og:url" content="{canonical}">
<meta property="og:image" content="{base}/assets/og-image.svg">
<meta property="og:image:alt" content="The Parlor Barbershop wordmark above the address 1209 Fort Worth Avenue, Dallas">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="{og_title}">
<meta name="twitter:description" content="{desc}">
<meta name="twitter:image" content="{base}/assets/og-image.svg">
<script type="application/ld+json">
{ld}
</script>
</head>
<body>
{header}
{body}
{footer}
</body>
</html>
"""


def build():
    for page in PAGES:
        body = (ROOT / page["body"]).read_text()
        nav = page["nav"]
        hdr = header
        for key, name in (("home", "__NAV_HOME__"), ("services", "__NAV_SERVICES__"),
                          ("shop", "__NAV_SHOP__"), ("visit", "__NAV_VISIT__")):
            hdr = hdr.replace(name, ' aria-current="page"' if nav == key else "")

        ld = {"@context": "https://schema.org", "@graph": page["ld"]}
        html = TEMPLATE.format(
            head=head_common.strip(),
            title=page["title"],
            desc=page["desc"],
            og_title=page["og_title"],
            canonical=BASE + page["slug"],
            base=BASE,
            robots='<meta name="robots" content="noindex, follow">\n' if page.get("noindex") else "",
            ld=json.dumps(ld, indent=2, ensure_ascii=False),
            header=hdr.rstrip(),
            body=body.rstrip(),
            footer=footer.rstrip(),
        )
        (ROOT / page["file"]).write_text(html)
        print("built", page["file"], len(html), "bytes")


if __name__ == "__main__":
    build()
