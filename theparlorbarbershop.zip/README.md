# The Parlor Barbershop — website

Static site. No build step required to deploy: upload the five `.html` files,
`styles.css`, `main.js`, `assets/`, `robots.txt` and `sitemap.xml` to any host.
Opening `index.html` directly in a browser also works.

## Before you go live — confirm these five things

The brief flagged conflicting information across directory listings. The site
ships with the most-corroborated value in each case. Every one of them is in a
single place, listed here.

| Item | On the site now | Where to change it |
| --- | --- | --- |
| Phone | (469) 677-0690 | Search `4696770690` across all `.html` files and `build.py` |
| Saturday close | 15:00, with an on-page note that listings disagree | `_body_index.part`, `_body_visit.part`, `build.py` |
| Booksy link | `https://booksy.com/en-us/` (not deep-linked) | `_body_visit.part`, the "Book on Booksy" button |
| Domain | `https://theparlorbarbershop.com` | `BASE` at the top of `build.py`, plus `robots.txt` and `sitemap.xml` |
| Prices | $40 / +$10, attributed on-page to Eddie Sanchez's posted rates | `_body_index.part`, `_body_services.part`, `build.py` |

## How to edit

1. **Design tokens** live at the top of `styles.css` under `:root` — colors in
   OKLCH with role names, one spacing scale, one type scale. Change the palette by
   editing `--surface`, `--ink`, `--accent` and their friends; the dark scheme
   redefines only those same tokens inside `@media (prefers-color-scheme: dark)`.
2. **Type scale** is the `--t-*` clamp values in the same block. They are fluid —
   there are no breakpoint jumps to keep in sync.
3. **Copy** lives in `_body_*.part`. Edit those, then run `python3 build.py` to
   regenerate the `.html` files. The header, footer and `<head>` are shared from
   `_header.part`, `_footer.part` and `_head.part`, so a change to the nav or the
   address happens once.
4. **To add a photograph**, drop the file in `assets/`, then replace one of the
   `.plate` blocks with `<img src="assets/your-file.jpg" alt="…" width="…"
   height="…" loading="lazy" decoding="async">`. Give it `object-fit: cover` and an
   `object-position` chosen for that image so faces survive the mobile crop.
5. **To connect the booking form**, open `main.js` and replace the block marked
   `Placeholder: no endpoint is wired` with a `fetch()` to your handler. Keep the
   loading, success and error states around it — they are already built.
6. **After changing `styles.css` or `main.js`**, bump the `?v=` number in
   `_head.part` and `_footer.part` and rebuild, so returning visitors get the new
   file instead of a cached one.

## Structure

- `index.html` · home
- `services.html` · services and prices
- `shop.html` · about the shop
- `visit.html` · hours, directions, booking form
- `404.html` · not-found page (point your host's 404 handler at it)
- `styles.css` · all styling, sectioned and commented
- `main.js` · menu, scroll reveals, the spine, the fade, form validation
- `build.py` · assembles the pages from the shared parts
- `_*.part` · the shared chrome and per-page bodies

Last updated 7 September 2026.
