/* ==========================================================================
   The Parlor Barbershop — behaviour
   Everything here is enhancement. The pages read completely without it.
   ========================================================================== */

(function () {
  "use strict";

  document.documentElement.classList.remove("no-js");

  var reduced = window.matchMedia("(prefers-reduced-motion: reduce)");

  /* ---------------------------------------------------------------------
     Masthead: hairline appears once the page has moved.
     --------------------------------------------------------------------- */
  var masthead = document.querySelector(".masthead");
  if (masthead) {
    var setScrolled = function () {
      masthead.dataset.scrolled = window.scrollY > 8 ? "true" : "false";
    };
    setScrolled();
    window.addEventListener("scroll", setScrolled, { passive: true });
  }

  /* ---------------------------------------------------------------------
     Mobile menu. Opens, closes four ways, traps focus, locks scroll,
     returns focus to the trigger.
     --------------------------------------------------------------------- */
  var menu = document.getElementById("menu");
  var menuBtn = document.querySelector(".menu-btn");

  if (menu && menuBtn) {
    var closeBtn = menu.querySelector("[data-menu-close]");
    var lastFocused = null;

    var focusables = function () {
      return Array.prototype.filter.call(
        menu.querySelectorAll('a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])'),
        function (el) { return el.offsetParent !== null; }
      );
    };

    var openMenu = function () {
      lastFocused = document.activeElement;
      menu.dataset.open = "true";
      menu.removeAttribute("inert");
      menuBtn.setAttribute("aria-expanded", "true");
      document.body.dataset.menuOpen = "true";
      var first = focusables()[0];
      if (first) { first.focus(); }
      document.addEventListener("keydown", onKeydown);
      document.addEventListener("pointerdown", onOutside, true);
    };

    var closeMenu = function (returnFocus) {
      menu.dataset.open = "false";
      menu.setAttribute("inert", "");
      menuBtn.setAttribute("aria-expanded", "false");
      delete document.body.dataset.menuOpen;
      document.removeEventListener("keydown", onKeydown);
      document.removeEventListener("pointerdown", onOutside, true);
      if (returnFocus !== false) {
        var target = menuBtn;
        if (lastFocused && lastFocused !== document.body && document.contains(lastFocused)) {
          target = lastFocused;
        }
        target.focus();
      }
    };

    var onKeydown = function (e) {
      if (e.key === "Escape") { e.preventDefault(); closeMenu(); return; }
      if (e.key !== "Tab") { return; }
      var items = focusables();
      if (!items.length) { return; }
      var first = items[0];
      var last = items[items.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      else if (!menu.contains(document.activeElement)) { e.preventDefault(); first.focus(); }
    };

    /* Outside click. The panel fills the screen, so "outside" means the empty
       ground around the links rather than a backdrop behind them. */
    var onOutside = function (e) {
      if (menu.dataset.open !== "true") { return; }
      var t = e.target;
      if (!(t instanceof Element)) { closeMenu(); return; }
      if (!menu.contains(t) || !t.closest("a, button")) { closeMenu(); }
    };

    menuBtn.addEventListener("click", function () {
      menu.dataset.open === "true" ? closeMenu() : openMenu();
    });
    if (closeBtn) { closeBtn.addEventListener("click", function () { closeMenu(); }); }

    menu.addEventListener("click", function (e) {
      var link = e.target.closest("a[href]");
      if (link) { closeMenu(false); }
    });

    window.matchMedia("(min-width: 56rem)").addEventListener("change", function (e) {
      if (e.matches && menu.dataset.open === "true") { closeMenu(false); }
    });

    menu.setAttribute("inert", "");
  }

  /* ---------------------------------------------------------------------
     The spine. Drawn as the page scrolls. Falls back fully drawn.
     --------------------------------------------------------------------- */
  var spines = document.querySelectorAll(".spine");
  if (spines.length && !reduced.matches) {
    var ticking = false;
    var drawSpine = function () {
      ticking = false;
      var doc = document.documentElement;
      var scrollable = doc.scrollHeight - window.innerHeight;
      var p = scrollable > 0 ? Math.min(1, Math.max(0, window.scrollY / scrollable)) : 1;
      /* The line always reaches at least the fold so it never looks unfinished. */
      var drawn = Math.min(1, 0.08 + p * 0.94);
      doc.style.setProperty("--spine-progress", drawn.toFixed(4));
      doc.style.setProperty("--spine-cap-opacity", p > 0.005 && p < 0.995 ? "1" : "0");
    };
    var requestDraw = function () {
      if (!ticking) { ticking = true; requestAnimationFrame(drawSpine); }
    };
    drawSpine();
    window.addEventListener("scroll", requestDraw, { passive: true });
    window.addEventListener("resize", requestDraw, { passive: true });
  }

  /* ---------------------------------------------------------------------
     Reveal on scroll. Transform and opacity only. Fires once.
     --------------------------------------------------------------------- */
  var revealables = document.querySelectorAll("[data-reveal]");
  if (revealables.length) {
    if (!("IntersectionObserver" in window) || reduced.matches) {
      revealables.forEach(function (el) { el.dataset.shown = "true"; });
    } else {
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (!entry.isIntersecting) { return; }
          var el = entry.target;
          var group = el.parentElement ? el.parentElement.querySelectorAll(":scope > [data-reveal]") : [el];
          var i = Array.prototype.indexOf.call(group, el);
          el.style.setProperty("--reveal-delay", Math.max(0, i) * 70 + "ms");
          el.dataset.shown = "true";
          io.unobserve(el);
        });
      }, { rootMargin: "0px 0px -12% 0px", threshold: 0.08 });
      revealables.forEach(function (el) { io.observe(el); });
    }
  }

  /* ---------------------------------------------------------------------
     The fade. The one reward for attention: the cursor sets the fade line,
     the way you set it in the chair.
     --------------------------------------------------------------------- */
  var band = document.querySelector(".fade-band");
  if (band && window.matchMedia("(hover: hover) and (pointer: fine)").matches) {
    var readout = band.querySelector("[data-fade-readout]");
    var name = function (pct) {
      if (pct < 32) { return "LOW FADE"; }
      if (pct < 54) { return "MID FADE"; }
      return "HIGH FADE";
    };
    /* Throttled on the event clock rather than the frame clock: two custom
       property writes are cheap, and this keeps working in a background tab
       where requestAnimationFrame is suspended. */
    var lastRun = 0;
    var applyFade = function (clientY) {
      var rect = band.getBoundingClientRect();
      var pct = ((clientY - rect.top) / rect.height) * 100;
      pct = Math.min(72, Math.max(18, pct));
      band.style.setProperty("--fade-stop", pct.toFixed(1) + "%");
      if (readout) { readout.textContent = name(pct); }
    };
    band.addEventListener("pointermove", function (e) {
      if (e.timeStamp - lastRun < 16) { return; }
      lastRun = e.timeStamp;
      applyFade(e.clientY);
    }, { passive: true });
  }

  /* ---------------------------------------------------------------------
     Today's hours, in shop time (America/Chicago).
     --------------------------------------------------------------------- */
  document.querySelectorAll("[data-hours]").forEach(function (table) {
    var today;
    try {
      today = new Intl.DateTimeFormat("en-US", {
        timeZone: "America/Chicago", weekday: "long"
      }).format(new Date());
    } catch (err) {
      today = new Date().toLocaleDateString("en-US", { weekday: "long" });
    }
    var row = table.querySelector('[data-day="' + today + '"]');
    if (row) {
      row.dataset.today = "true";
      var flag = row.querySelector("[data-today-flag]");
      if (flag) { flag.textContent = "Today"; }
    }
  });

  /* ---------------------------------------------------------------------
     Booking form. No endpoint is connected yet — see the README note.
     Validation, error, loading and success states are all real.
     --------------------------------------------------------------------- */
  var form = document.getElementById("booking-form");
  if (form) {
    var success = form.querySelector("[data-success]");
    var submitBtn = form.querySelector('button[type="submit"]');
    var attempted = false;

    var messageFor = function (input) {
      var v = input.validity;
      if (v.valueMissing) {
        if (input.tagName === "SELECT") { return "Pick the service you want so we book enough time."; }
        return input.dataset.missing || "This one is needed.";
      }
      if (v.typeMismatch && input.type === "email") { return "That email is missing something — check for the @ and the domain."; }
      if (v.tooShort) { return "A little more than that, please."; }
      if (v.patternMismatch) { return input.dataset.pattern || "Check the format on this one."; }
      return "Have another look at this one.";
    };

    var validate = function (input) {
      var field = input.closest(".field");
      if (!field) { return input.checkValidity(); }
      var ok = input.checkValidity();
      field.dataset.invalid = ok ? "false" : "true";
      input.setAttribute("aria-invalid", ok ? "false" : "true");
      var slot = field.querySelector("[data-error-text]");
      if (slot) { slot.textContent = ok ? "" : messageFor(input); }
      return ok;
    };

    var controls = Array.prototype.slice.call(
      form.querySelectorAll("input, select, textarea")
    );

    controls.forEach(function (input) {
      input.addEventListener("blur", function () { if (attempted) { validate(input); } });
      input.addEventListener("input", function () { if (attempted) { validate(input); } });
    });

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      attempted = true;
      var firstBad = null;
      controls.forEach(function (input) {
        if (!validate(input) && !firstBad) { firstBad = input; }
      });
      if (firstBad) {
        firstBad.focus();
        firstBad.scrollIntoView({ block: "center", behavior: reduced.matches ? "auto" : "smooth" });
        return;
      }

      submitBtn.dataset.loading = "true";
      submitBtn.setAttribute("aria-busy", "true");

      /* Placeholder: no endpoint is wired. Replace this block with a real
         fetch() to your form handler — see README.md. */
      window.setTimeout(function () {
        delete submitBtn.dataset.loading;
        submitBtn.removeAttribute("aria-busy");
        form.reset();
        attempted = false;
        controls.forEach(function (input) {
          var f = input.closest(".field");
          if (f) { f.dataset.invalid = "false"; }
          input.removeAttribute("aria-invalid");
        });
        if (success) {
          success.dataset.shown = "true";
          success.focus();
        }
      }, 700);
    });
  }

  /* ---------------------------------------------------------------------
     Footer year.
     --------------------------------------------------------------------- */
  document.querySelectorAll("[data-year]").forEach(function (el) {
    el.textContent = String(new Date().getFullYear());
  });
})();
